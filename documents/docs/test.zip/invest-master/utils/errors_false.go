package utils

var NoErrorFineEverthingOk = map[string]interface{}{
	"eng": "ok",
	"rus": "ok",
	"kaz": "ok",
}

